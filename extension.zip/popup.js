document.addEventListener("DOMContentLoaded",()=>{const o={bgColor:document.getElementById("bgColor"),bgOpacity:document.getElementById("bgOpacity"),hoverColor:document.getElementById("hoverColor"),buttonList:document.getElementById("buttonList"),addBtn:document.getElementById("addBtn"),saveBtn:document.getElementById("save"),status:document.getElementById("status")},l={style:{bgColor:"#1e293b",bgOpacity:.95,hoverColor:"#3b82f6",hoverOpacity:.2,borderRadius:12,buttonSize:36,buttonSpacing:6,padding:6,iconSize:20},buttons:[{id:"copy",type:"action",action:"copy",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>'}]};let e=null;chrome.storage.sync.get(["canvasToastConfig"],t=>{e=t.canvasToastConfig||l,e.style||(e.style=l.style),e.buttons||(e.buttons=l.buttons),c()});function c(){o.bgColor.value=e.style.bgColor,o.bgOpacity.value=e.style.bgOpacity,o.hoverColor.value=e.style.hoverColor,o.buttonList.innerHTML="",e.buttons.forEach((t,n)=>{const i=document.createElement("div");i.className="btn-item";let a=`
        <div class="btn-header">
          <span>Action ${n+1}</span>
          <span class="btn-remove" data-index="${n}">\u2716</span>
        </div>
        <select class="config-input type-select" data-field="type" data-index="${n}">
          <option value="action" ${t.type==="action"?"selected":""}>System Action</option>
          <option value="link" ${t.type==="link"?"selected":""}>Search / Link</option>
        </select>
      `;t.type==="action"?a+=`
          <select class="config-input" data-field="action" data-index="${n}">
            <option value="copy" ${t.action==="copy"?"selected":""}>Copy Text</option>
            <option value="paste" ${t.action==="paste"?"selected":""}>Paste Text</option>
          </select>
        `:a+=`
          <input type="text" class="config-input" data-field="url" data-index="${n}" 
                 value="${t.url||""}" placeholder="https://google.com/search?q=%s">
          <span class="helper-text">Use %s for selected text</span>
        `,a+=`
        <span class="helper-text">SVG Icon Code:</span>
        <textarea class="config-input" data-field="icon" data-index="${n}">${t.icon}</textarea>
      `,i.innerHTML=a,o.buttonList.appendChild(i)}),d()}function d(){document.querySelectorAll(".btn-remove").forEach(t=>{t.addEventListener("click",n=>{e.buttons.splice(n.target.dataset.index,1),c()})}),document.querySelectorAll(".config-input").forEach(t=>{t.addEventListener("change",n=>{const i=n.target.dataset.index,a=n.target.dataset.field,s=e.buttons[i];a==="type"?(s.type=n.target.value,s.type==="link"&&(s.url="https://google.com/search?q=%s"),s.type==="action"&&(s.action="copy"),c()):s[a]=n.target.value})})}o.bgColor.addEventListener("change",t=>e.style.bgColor=t.target.value),o.bgOpacity.addEventListener("input",t=>e.style.bgOpacity=parseFloat(t.target.value)),o.hoverColor.addEventListener("change",t=>e.style.hoverColor=t.target.value),o.addBtn.addEventListener("click",()=>{e.buttons.push({id:"btn-"+Date.now(),type:"link",url:"https://",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>'}),c()}),o.saveBtn.addEventListener("click",()=>{o.saveBtn.textContent="Saving...",chrome.storage.sync.set({canvasToastConfig:e},()=>{o.saveBtn.textContent="Save Changes",o.status.style.opacity="1",setTimeout(()=>{o.status.style.opacity="0"},2e3)})})});
