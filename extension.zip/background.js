function _(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e}function y(e,r){return Array(r+1).join(e)}function S(e){return e.replace(/^\n*/,"")}function w(e){for(var r=e.length;r>0&&e[r-1]===`
`;)r--;return e.substring(0,r)}function B(e){return w(S(e))}var j=["ADDRESS","ARTICLE","ASIDE","AUDIO","BLOCKQUOTE","BODY","CANVAS","CENTER","DD","DIR","DIV","DL","DT","FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","FRAMESET","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","HTML","ISINDEX","LI","MAIN","MENU","NAV","NOFRAMES","NOSCRIPT","OL","OUTPUT","P","PRE","SECTION","TABLE","TBODY","TD","TFOOT","TH","THEAD","TR","UL"];function k(e){return A(e,j)}var D=["AREA","BASE","BR","COL","COMMAND","EMBED","HR","IMG","INPUT","KEYGEN","LINK","META","PARAM","SOURCE","TRACK","WBR"];function x(e){return A(e,D)}function K(e){return P(e,D)}var L=["A","TABLE","THEAD","TBODY","TFOOT","TH","TD","IFRAME","SCRIPT","AUDIO","VIDEO"];function G(e){return A(e,L)}function X(e){return P(e,L)}function A(e,r){return r.indexOf(e.nodeName)>=0}function P(e,r){return e.getElementsByTagName&&r.some(function(t){return e.getElementsByTagName(t).length})}var Y=[[/\\/g,"\\\\"],[/\*/g,"\\*"],[/^-/g,"\\-"],[/^\+ /g,"\\+ "],[/^(=+)/g,"\\$1"],[/^(#{1,6}) /g,"\\$1 "],[/`/g,"\\`"],[/^~~~/g,"\\~~~"],[/\[/g,"\\["],[/\]/g,"\\]"],[/^>/g,"\\>"],[/_/g,"\\_"],[/^(\d+)\. /g,"$1\\. "]];function M(e){return Y.reduce(function(r,t){return r.replace(t[0],t[1])},e)}var s={};s.paragraph={filter:"p",replacement:function(e){return`

`+e+`

`}};s.lineBreak={filter:"br",replacement:function(e,r,t){return t.br+`
`}};s.heading={filter:["h1","h2","h3","h4","h5","h6"],replacement:function(e,r,t){var n=Number(r.nodeName.charAt(1));if(t.headingStyle==="setext"&&n<3){var i=y(n===1?"=":"-",e.length);return`

`+e+`
`+i+`

`}else return`

`+y("#",n)+" "+e+`

`}};s.blockquote={filter:"blockquote",replacement:function(e){return e=B(e).replace(/^/gm,"> "),`

`+e+`

`}};s.list={filter:["ul","ol"],replacement:function(e,r){var t=r.parentNode;return t.nodeName==="LI"&&t.lastElementChild===r?`
`+e:`

`+e+`

`}};s.listItem={filter:"li",replacement:function(e,r,t){var n=t.bulletListMarker+"   ",i=r.parentNode;if(i.nodeName==="OL"){var a=i.getAttribute("start"),o=Array.prototype.indexOf.call(i.children,r);n=(a?Number(a)+o:o+1)+".  "}var u=/\n$/.test(e);return e=B(e)+(u?`
`:""),e=e.replace(/\n/gm,`
`+" ".repeat(n.length)),n+e+(r.nextSibling?`
`:"")}};s.indentedCodeBlock={filter:function(e,r){return r.codeBlockStyle==="indented"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,r,t){return`

    `+r.firstChild.textContent.replace(/\n/g,`
    `)+`

`}};s.fencedCodeBlock={filter:function(e,r){return r.codeBlockStyle==="fenced"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,r,t){for(var n=r.firstChild.getAttribute("class")||"",i=(n.match(/language-(\S+)/)||[null,""])[1],a=r.firstChild.textContent,o=t.fence.charAt(0),u=3,l=new RegExp("^"+o+"{3,}","gm"),f;f=l.exec(a);)f[0].length>=u&&(u=f[0].length+1);var h=y(o,u);return`

`+h+i+`
`+a.replace(/\n$/,"")+`
`+h+`

`}};s.horizontalRule={filter:"hr",replacement:function(e,r,t){return`

`+t.hr+`

`}};s.inlineLink={filter:function(e,r){return r.linkStyle==="inlined"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,r){var t=T(r.getAttribute("href")),n=E(p(r.getAttribute("title"))),i=n?' "'+n+'"':"";return"["+e+"]("+t+i+")"}};s.referenceLink={filter:function(e,r){return r.linkStyle==="referenced"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,r,t){var n=T(r.getAttribute("href")),i=p(r.getAttribute("title"));i&&(i=' "'+E(i)+'"');var a,o;switch(t.linkReferenceStyle){case"collapsed":a="["+e+"][]",o="["+e+"]: "+n+i;break;case"shortcut":a="["+e+"]",o="["+e+"]: "+n+i;break;default:var u=this.references.length+1;a="["+e+"]["+u+"]",o="["+u+"]: "+n+i}return this.references.push(o),a},references:[],append:function(e){var r="";return this.references.length&&(r=`

`+this.references.join(`
`)+`

`,this.references=[]),r}};s.emphasis={filter:["em","i"],replacement:function(e,r,t){return e.trim()?t.emDelimiter+e+t.emDelimiter:""}};s.strong={filter:["strong","b"],replacement:function(e,r,t){return e.trim()?t.strongDelimiter+e+t.strongDelimiter:""}};s.code={filter:function(e){var r=e.previousSibling||e.nextSibling,t=e.parentNode.nodeName==="PRE"&&!r;return e.nodeName==="CODE"&&!t},replacement:function(e){if(!e)return"";e=e.replace(/\r?\n|\r/g," ");for(var r=/^`|^ .*?[^ ].* $|`$/.test(e)?" ":"",t="`",n=e.match(/`+/gm)||[];n.indexOf(t)!==-1;)t=t+"`";return t+r+e+r+t}};s.image={filter:"img",replacement:function(e,r){var t=M(p(r.getAttribute("alt"))),n=T(r.getAttribute("src")||""),i=p(r.getAttribute("title")),a=i?' "'+E(i)+'"':"";return n?"!["+t+"]("+n+a+")":""}};function p(e){return e?e.replace(/(\n+\s*)+/g,`
`):""}function T(e){var r=e.replace(/([<>()])/g,"\\$1");return r.indexOf(" ")>=0?"<"+r+">":r}function E(e){return e.replace(/"/g,'\\"')}function I(e){this.options=e,this._keep=[],this._remove=[],this.blankRule={replacement:e.blankReplacement},this.keepReplacement=e.keepReplacement,this.defaultRule={replacement:e.defaultReplacement},this.array=[];for(var r in e.rules)this.array.push(e.rules[r])}I.prototype={add:function(e,r){this.array.unshift(r)},keep:function(e){this._keep.unshift({filter:e,replacement:this.keepReplacement})},remove:function(e){this._remove.unshift({filter:e,replacement:function(){return""}})},forNode:function(e){if(e.isBlank)return this.blankRule;var r;return(r=g(this.array,e,this.options))||(r=g(this._keep,e,this.options))||(r=g(this._remove,e,this.options))?r:this.defaultRule},forEach:function(e){for(var r=0;r<this.array.length;r++)e(this.array[r],r)}};function g(e,r,t){for(var n=0;n<e.length;n++){var i=e[n];if(z(i,r,t))return i}}function z(e,r,t){var n=e.filter;if(typeof n=="string"){if(n===r.nodeName.toLowerCase())return!0}else if(Array.isArray(n)){if(n.indexOf(r.nodeName.toLowerCase())>-1)return!0}else if(typeof n=="function"){if(n.call(e,r,t))return!0}else throw new TypeError("`filter` needs to be a string, array, or function")}function J(e){var r=e.element,t=e.isBlock,n=e.isVoid,i=e.isPre||function(U){return U.nodeName==="PRE"};if(!(!r.firstChild||i(r))){for(var a=null,o=!1,u=null,l=R(u,r,i);l!==r;){if(l.nodeType===3||l.nodeType===4){var f=l.data.replace(/[ \r\n\t]+/g," ");if((!a||/ $/.test(a.data))&&!o&&f[0]===" "&&(f=f.substr(1)),!f){l=v(l);continue}l.data=f,a=l}else if(l.nodeType===1)t(l)||l.nodeName==="BR"?(a&&(a.data=a.data.replace(/ $/,"")),a=null,o=!1):n(l)||i(l)?(a=null,o=!0):a&&(o=!1);else{l=v(l);continue}var h=R(u,l,i);u=l,l=h}a&&(a.data=a.data.replace(/ $/,""),a.data||v(a))}}function v(e){var r=e.nextSibling||e.parentNode;return e.parentNode.removeChild(e),r}function R(e,r,t){return e&&e.parentNode===r||t(r)?r.nextSibling||r.parentNode:r.firstChild||r.nextSibling||r.parentNode}var C=typeof window<"u"?window:{};function Q(){var e=C.DOMParser,r=!1;try{new e().parseFromString("","text/html")&&(r=!0)}catch{}return r}function Z(){var e=function(){};return q()?e.prototype.parseFromString=function(r){var t=new window.ActiveXObject("htmlfile");return t.designMode="on",t.open(),t.write(r),t.close(),t}:e.prototype.parseFromString=function(r){var t=document.implementation.createHTMLDocument("");return t.open(),t.write(r),t.close(),t},e}function q(){var e=!1;try{document.implementation.createHTMLDocument("").open()}catch{C.ActiveXObject&&(e=!0)}return e}var ee=Q()?C.DOMParser:Z();function re(e,r){var t;if(typeof e=="string"){var n=te().parseFromString('<x-turndown id="turndown-root">'+e+"</x-turndown>","text/html");t=n.getElementById("turndown-root")}else t=e.cloneNode(!0);return J({element:t,isBlock:k,isVoid:x,isPre:r.preformattedCode?ne:null}),t}var N;function te(){return N=N||new ee,N}function ne(e){return e.nodeName==="PRE"||e.nodeName==="CODE"}function ie(e,r){return e.isBlock=k(e),e.isCode=e.nodeName==="CODE"||e.parentNode.isCode,e.isBlank=ae(e),e.flankingWhitespace=le(e,r),e}function ae(e){return!x(e)&&!G(e)&&/^\s*$/i.test(e.textContent)&&!K(e)&&!X(e)}function le(e,r){if(e.isBlock||r.preformattedCode&&e.isCode)return{leading:"",trailing:""};var t=oe(e.textContent);return t.leadingAscii&&O("left",e,r)&&(t.leading=t.leadingNonAscii),t.trailingAscii&&O("right",e,r)&&(t.trailing=t.trailingNonAscii),{leading:t.leading,trailing:t.trailing}}function oe(e){var r=e.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);return{leading:r[1],leadingAscii:r[2],leadingNonAscii:r[3],trailing:r[4],trailingNonAscii:r[5],trailingAscii:r[6]}}function O(e,r,t){var n,i,a;return e==="left"?(n=r.previousSibling,i=/ $/):(n=r.nextSibling,i=/^ /),n&&(n.nodeType===3?a=i.test(n.nodeValue):t.preformattedCode&&n.nodeName==="CODE"?a=!1:n.nodeType===1&&!k(n)&&(a=i.test(n.textContent))),a}var se=Array.prototype.reduce;function d(e){if(!(this instanceof d))return new d(e);var r={rules:s,headingStyle:"setext",hr:"* * *",bulletListMarker:"*",codeBlockStyle:"indented",fence:"```",emDelimiter:"_",strongDelimiter:"**",linkStyle:"inlined",linkReferenceStyle:"full",br:"  ",preformattedCode:!1,blankReplacement:function(t,n){return n.isBlock?`

`:""},keepReplacement:function(t,n){return n.isBlock?`

`+n.outerHTML+`

`:n.outerHTML},defaultReplacement:function(t,n){return n.isBlock?`

`+t+`

`:t}};this.options=_({},r,e),this.rules=new I(this.options)}d.prototype={turndown:function(e){if(!ce(e))throw new TypeError(e+" is not a string, or an element/document/fragment node.");if(e==="")return"";var r=H.call(this,new re(e,this.options));return ue.call(this,r)},use:function(e){if(Array.isArray(e))for(var r=0;r<e.length;r++)this.use(e[r]);else if(typeof e=="function")e(this);else throw new TypeError("plugin must be a Function or an Array of Functions");return this},addRule:function(e,r){return this.rules.add(e,r),this},keep:function(e){return this.rules.keep(e),this},remove:function(e){return this.rules.remove(e),this},escape:function(e){return M(e)}};function H(e){var r=this;return se.call(e.childNodes,function(t,n){n=new ie(n,r.options);var i="";return n.nodeType===3?i=n.isCode?n.nodeValue:r.escape(n.nodeValue):n.nodeType===1&&(i=fe.call(r,n)),F(t,i)},"")}function ue(e){var r=this;return this.rules.forEach(function(t){typeof t.append=="function"&&(e=F(e,t.append(r.options)))}),e.replace(/^[\t\r\n]+/,"").replace(/[\t\r\n\s]+$/,"")}function fe(e){var r=this.rules.forNode(e),t=H.call(this,e),n=e.flankingWhitespace;return(n.leading||n.trailing)&&(t=t.trim()),n.leading+r.replacement(t,e,this.options)+n.trailing}function F(e,r){var t=w(e),n=S(r),i=Math.max(e.length-t.length,r.length-n.length),a=`

`.substring(0,i);return t+a+n}function ce(e){return e!=null&&(typeof e=="string"||e.nodeType&&(e.nodeType===1||e.nodeType===9||e.nodeType===11))}var $=/highlight-(?:text|source)-([a-z0-9]+)/;function de(e){e.addRule("highlightedCodeBlock",{filter:function(r){var t=r.firstChild;return r.nodeName==="DIV"&&$.test(r.className)&&t&&t.nodeName==="PRE"},replacement:function(r,t,n){var i=t.className||"",a=(i.match($)||[null,""])[1];return`

`+n.fence+a+`
`+t.firstChild.textContent+`
`+n.fence+`

`}})}function he(e){e.addRule("strikethrough",{filter:["del","s","strike"],replacement:function(r){return"~"+r+"~"}})}var pe=Array.prototype.indexOf,me=Array.prototype.every,c={};c.tableCell={filter:["th","td"],replacement:function(e,r){return V(e,r)}};c.tableRow={filter:"tr",replacement:function(e,r){var t="",n={left:":--",right:"--:",center:":-:"};if(b(r))for(var i=0;i<r.childNodes.length;i++){var a="---",o=(r.childNodes[i].getAttribute("align")||"").toLowerCase();o&&(a=n[o]||a),t+=V(a,r.childNodes[i])}return`
`+e+(t?`
`+t:"")}};c.table={filter:function(e){return e.nodeName==="TABLE"&&b(e.rows[0])},replacement:function(e){return e=e.replace(`

`,`
`),`

`+e+`

`}};c.tableSection={filter:["thead","tbody","tfoot"],replacement:function(e){return e}};function b(e){var r=e.parentNode;return r.nodeName==="THEAD"||r.firstChild===e&&(r.nodeName==="TABLE"||ge(r))&&me.call(e.childNodes,function(t){return t.nodeName==="TH"})}function ge(e){var r=e.previousSibling;return e.nodeName==="TBODY"&&(!r||r.nodeName==="THEAD"&&/^\s*$/i.test(r.textContent))}function V(e,r){var t=pe.call(r.parentNode.childNodes,r),n=" ";return t===0&&(n="| "),n+e+" |"}function ve(e){e.keep(function(t){return t.nodeName==="TABLE"&&!b(t.rows[0])});for(var r in c)e.addRule(r,c[r])}function Ne(e){e.addRule("taskListItems",{filter:function(r){return r.type==="checkbox"&&r.parentNode.nodeName==="LI"},replacement:function(r,t){return(t.checked?"[x]":"[ ]")+" "}})}function W(e){e.use([de,he,ve,Ne])}var m=new d({headingStyle:"atx",bulletListMarker:"-",codeBlockStyle:"fenced",fence:"```",hr:"---",linkStyle:"inlined"});m.use(W);m.addRule("removeHidden",{filter:e=>e.style&&(e.style.display==="none"||e.style.visibility==="hidden"),replacement:()=>""});m.addRule("lineBreak",{filter:"br",replacement:()=>`  
`});chrome.runtime.onMessage.addListener((e,r,t)=>(e.type==="MARKDOWN"?t({markdown:m.turndown(e.html)}):e.type==="WEBHOOK"&&(fetch(e.url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({selection:e.text,url:r.tab.url})}).catch(n=>console.error("Webhook fail:",n)),t({success:!0})),!0));
