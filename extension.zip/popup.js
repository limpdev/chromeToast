document.addEventListener("DOMContentLoaded",()=>{const a={buttonList:document.getElementById("buttonList"),addBtn:document.getElementById("addBtn"),saveBtn:document.getElementById("save"),status:document.getElementById("status"),styleInputs:document.querySelectorAll(".style-input")},l={style:{bgColor:"#0f172a",bgOpacity:.95,hoverColor:"#3b82f6",hoverOpacity:.2,borderRadius:12,buttonSize:36,buttonSpacing:6,padding:6,iconSize:20,animSpeed:.2,hoverScale:1.15,activeScale:.95,iconLift:3},buttons:[{id:"copy",type:"action",action:"copy",icon:'<svg viewBox="0 0 24 24" fill="#e2e8f0" xmlns="http://www.w3.org/2000/svg"><path d="M16 1H4C2.9 1 2 1.9 2 3V17H4V3H16V1ZM19 5H8C6.9 5 6 5.9 6 7V21C6 22.1 6.9 23 8 23H19C20.1 23 21 22.1 21 21V7C21 5.9 20.1 5 19 5ZM19 21H8V7H19V21Z"/></svg>'},{id:"google",type:"link",url:"https://www.google.com/search?q=%s",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>'}]};let i=null;chrome.storage.sync.get(["canvasToastConfig"],e=>{const t=e.canvasToastConfig||{};i={style:{...l.style,...t.style||{}},buttons:t.buttons&&t.buttons.length>0?t.buttons:l.buttons},c()});function c(){a.styleInputs.forEach(e=>{const t=e.dataset.key;if(i.style[t]!==void 0){e.value=i.style[t];const o=document.getElementById(`val-${t}`);o&&(o.textContent=i.style[t])}}),a.buttonList.innerHTML="",i.buttons.forEach((e,t)=>{const o=document.createElement("div");o.className="btn-item";let n=`
    <div class="btn-header">
      <span>Action ${t+1}</span>
      <span class="btn-remove" data-index="${t}">\u2716</span>
    </div>
    <select class="config-input type-select" data-field="type" data-index="${t}">
      <option value="action" ${e.type==="action"?"selected":""}>System Action</option>
      <option value="link" ${e.type==="link"?"selected":""}>Search / Link</option>
    </select>
  `;e.type==="action"?n+=`
      <select class="config-input" data-field="action" data-index="${t}">
        <option value="copy" ${e.action==="copy"?"selected":""}>Copy Text</option>
        <option value="paste" ${e.action==="paste"?"selected":""}>Paste Text</option>
      </select>
    `:n+=`
      <input type="text" class="config-input" data-field="url" data-index="${t}" 
             value="${e.url||""}" placeholder="https://google.com/search?q=%s">
      <span class="helper-text">Use %s for selected text</span>
    `,n+=`
    <span class="helper-text">SVG Icon Code:</span>
    <textarea class="config-input" data-field="icon" data-index="${t}">${e.icon}</textarea>
  `,o.innerHTML=n,a.buttonList.appendChild(o)}),d()}function d(){document.querySelectorAll(".btn-remove").forEach(e=>{e.addEventListener("click",t=>{i.buttons.splice(t.target.dataset.index,1),c()})}),document.querySelectorAll(".config-input").forEach(e=>{e.addEventListener("change",t=>{const o=t.target.dataset.index,n=t.target.dataset.field,s=i.buttons[o];n==="type"?(s.type=t.target.value,s.type==="link"&&(s.url="https://google.com/search?q=%s",delete s.action),s.type==="action"&&(s.action="copy",delete s.url),c()):s[n]=t.target.value})}),a.styleInputs.forEach(e=>{e.addEventListener("input",t=>{const o=t.target.dataset.key;let n=t.target.value;if(e.type==="range"){n=parseFloat(n);const s=document.getElementById(`val-${o}`);s&&(s.textContent=n)}i.style[o]=n})})}a.addBtn.addEventListener("click",()=>{i.buttons.push({id:"btn-"+Date.now(),type:"link",url:"https://",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/></svg>'}),c()}),a.saveBtn.addEventListener("click",()=>{a.saveBtn.textContent="Saving...",chrome.storage.sync.set({canvasToastConfig:i},()=>{a.saveBtn.textContent="Save Changes",a.status.style.opacity="1",setTimeout(()=>{a.status.style.opacity="0"},2e3)})})});
